{{	content

	if content.extract('footnote').count > 0
		if (not lastResults.last.hasSuffix("\n"))
			"\n\n"
		end
		if (not lastResults.last.hasSuffix("\n\n"))
			"\n"
		end
	end

	if content.extract('footnote').count > 0 
		for footnote in content.extract('footnote')
			}}[^{{ footnote.index }}]:	{{ 
			if (footnote.attributes.text.trim.length > 0)
				footnote.attributes.text.indentNewlines(1, '\t').trim
			end
			if (footnote.attributes.text.trim.length == 0)
				"."
			end

			if ((iterationIndex + 1) < iterationCount)
				"\n\n"
			end
		end
	end
}}