{{	content

	if (content.extract('footnote').count > 0) or ((not parameters.useInlineLinks) and (content.extract('link', 'image', 'video').count > 0))
		if (not lastResults.last.hasSuffix("\n"))
			"\n\n"
		end
		if (not lastResults.last.hasSuffix("\n\n"))
			"\n"
		end
	end

	if content.extract('footnote').count > 0 
		for footnote in content.extract('footnote')
			}}[^{{ footnote.index }}]:	{{ 
			if (footnote.attributes.text.trim.length > 0)
				footnote.attributes.text.indentNewlines(1, '\t').trim
			end
			if (footnote.attributes.text.trim.length == 0)
				"."
			end

			if ((iterationIndex + 1) < iterationCount)
				"\n\n"
			end
		end
	end
	
	if ((content.extract('link').count > 0) and (not parameters.useInlineLinks))
		if (content.extract('footnote').count > 0)
			"\n\n"
		end

		for link in content.extract('link')
			if ((link.attributes.URL.trim.length > 0) or (link.attributes.title.trim.length > 0))
				}}[{{ link.index }}]:	{{
				
				if (link.attributes.URL.urlEncode.unencodedContents.length > 0)
					link.attributes.URL.urlEncode.unencodedContents
				end
				if (link.attributes.URL.urlEncode.unencodedContents.length == 0)
					}}#{{
				end

				if (link.attributes.title.trim.length > 0)
					}} "{{ link.attributes.title.unencodedContents.trim }}"{{
				end

				if ((iterationIndex + 1) < iterationCount)
					"\n"
				end
			end
		end
	end	
	
	if ((content.extract('image').count > 0) and (not parameters.useInlineLinks))
		if ((content.extract('footnote').count > 0) or (content.extract('link').count > 0))
			"\n\n"
		end

		for image in content.extract('image')
			if ((image.attributes.URL.trim.length > 0) or (image.attributes.title.trim.length > 0))
				}}[{{ image.index }}]:	{{
				
				if (image.attributes.URL.urlEncode.unencodedContents.length > 0)
					image.attributes.URL.urlEncode.unencodedContents
				end
				if (image.attributes.URL.urlEncode.unencodedContents.length == 0)
					}}#{{
				end
				
				if (image.attributes.title.trim.length > 0)
					}} "{{ image.attributes.title.unencodedContents.trim }}"{{
				end

				if ((iterationIndex + 1) < iterationCount)
					"\n"
				end
			end
		end
	end
}}