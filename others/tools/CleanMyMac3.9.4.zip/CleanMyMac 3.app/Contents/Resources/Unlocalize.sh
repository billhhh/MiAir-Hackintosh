#!/bin/sh

#  Unlocalize.sh
#  CleanMyMac
#
#  Created by Vera Tkachenko on 12/5/17.
#  Copyright © 2017 MacPaw. All rights reserved.

LOCALES_TO_KEEP=$1
for var in "$@"
do
LOCALES_TO_KEEP="$LOCALES_TO_KEEP|$var"
done
find "${BUILT_PRODUCTS_DIR}/${CMM_PRODUCT_NAME}.app/Contents/". -name '*.lproj' | grep -E -v $LOCALES_TO_KEEP | grep -v CleanMyMac3Help.help | sed -e "s/.*/'&'/" | xargs rm -rf
